

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>DNA TO RNA</title>
</head>
<body >

<div class="form-container">
    <div class="form">
    <form action=""  method="post" >   
        <span class="heading">DNA TO RNA..</span>
        <input  class="input" required type="text" id="dna" name="DNA" style="text-transform: uppercase;" onkeydown="return /[a-z]/i.test(event.key)" placeholder="ENTER DNA" >
     
     
           <div class="button-container">
        <!-- <div class="send-button">Send</div> -->
        <input type="submit" value="Check DNA"  name="check"  class="send-button" >
        <div class="reset-button-container">
            <input  type="submit" value="Convert DNA" name="convert" class="reset-button" >
            <!-- <div  class="reset-button" >Convert Dna</div> -->
        </div>
        </form>
       
    </div>
  
</div>
</div>
<!---->
    <div class="cardd">
        <div class="card" style="display:;" id="card">
                <div class="card-inner">
                    
                  <div class="card-front">
                                      <p style="margin-top: -390px;text-decoration: underline;margin-left:40px;">DNA</p>

                                   <?php
                                      if(isset($_POST['check'])){
                                        $dna=$_POST['DNA'];
                                        $cdna=$dna;

                                        $cdna = count_chars($cdna,3);
                                        if(($cdna[0]=='a'&&$cdna[1]=='c')&&($cdna[2]=='g' &&$cdna[3]=='t')&&(strlen($cdna)==4))
                                        {
                                          echo'<script> alert("DNA VALID..")</script>';
                                          
                                        }
                                        else
                                        {
                                          echo'<script> alert("DNA INVALID..")</script>';
                                        }
                                        
                                      }


                                    ?>

                                    <?php
                                              if(isset($_POST['convert']))
                                              {
                                                // if($x==1)
                                                $dna=$_POST['DNA'];
                                                $cdna=$dna;
                                                $cdna = count_chars($cdna,3);
                                                if(($cdna[0]=='a'&&$cdna[1]=='c')&&($cdna[2]=='g' &&$cdna[3]=='t')&&(strlen($cdna)==4))
                                                {
                                                  $dna=$_POST['DNA'];
                                                  
                                                  
                                                }
                                                else
                                                {
                                                  echo'<script> alert("DNA INVALID..")</script>';
                                                  $dna="";
                                                }
                                    ?>

                                      <p id="d" style="text-transform: uppercase; word-break: break-all;margin-left:-60px;font-size:20px;padding:25px;margin:15px;"> <?php echo $dna?></p>
                                      
                                      <?php } ?>


                  </div>

                <div class="card-back">
                          <p style="margin-top: -390px;text-decoration: underline;margin-left:40px;">RNA</p>
                          <?php
                            if(isset($_POST['convert']))
                              {
                            
                                        $dna=$_POST['DNA'];
                                        $cdna=$dna;
                                        $cdna = count_chars($cdna,3);
                                        if(($cdna[0]=='a'&&$cdna[1]=='c')&&($cdna[2]=='g' &&$cdna[3]=='t')&&(strlen($cdna)==4))
                                        {
                                          $dna=$_POST['DNA'];
                                          $cdna1=$dna;
                                          $rna=str_replace("t","u",$cdna1);
                                          
                                        }
                                        else
                                        {
                                          // echo'<script> alert("DNA INVALID..")</script>';
                                          $rna="";
                                        }
                                        
                             
                                // echo $cdna;
                              
                          ?>
                          <br>  
                              <p id="r" style="text-transform: uppercase; word-break: break-all;margin-left:-150px;font-size:20px;padding:25px;margin:15px;"><?php echo $rna?></p>
                          <?php }?>


                  </div>
                </div>
        </div>  
  </div> 
</body>
</html>